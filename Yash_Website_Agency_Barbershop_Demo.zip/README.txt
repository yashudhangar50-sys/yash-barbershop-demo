Yash Website Agency — Barbershop Demo

Files:
- index.html: responsive demo website

Important:
- This is a sample/demo, not a real business website.
- Replace business name, prices, address, opening hours, phone, and email with verified client-approved details before publishing.
- No hosting or domain has been purchased.
- For free hosting, upload index.html to a GitHub repository and enable GitHub Pages. This step requires your own account and action.
